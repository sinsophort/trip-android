package app.tripexpense.calls;

import androidx.annotation.NonNull;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/**
 * Alerts from the Apps Script server (Firebase Cloud Messaging, "high priority" data messages).
 * ring = "1": an incoming call → full-screen ringing. "Missed …" for the same call → stop ringing.
 */
public class PushService extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(@NonNull RemoteMessage m) {
        Map<String, String> d = m.getData();
        String go = d.get("go"), title = d.get("title"), body = d.get("body"), tag = d.get("tag");
        if (title == null) title = "";
        if (body == null) body = "";
        boolean call = go != null && go.startsWith("call:");
        if (call && "1".equals(d.get("ring"))) {
            /* the app is open on the screen: it rings by itself */
            if (MainActivity.foreground) return;
            CallNotifier.ring(this, go, title, body);
            return;
        }
        if (call) CallNotifier.cancel(this, go);
        if (MainActivity.foreground && go != null && go.startsWith("chat:")) return; // the open app shows it
        CallNotifier.message(this, go, title, body, tag);
    }

    @Override
    public void onNewToken(@NonNull String token) {
        getSharedPreferences("trip", MODE_PRIVATE).edit().putString("token", token).apply();
        MainActivity a = MainActivity.live;
        if (a != null) a.tokenChanged(token);
    }
}
