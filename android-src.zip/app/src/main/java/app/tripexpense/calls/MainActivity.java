package app.tripexpense.calls;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The app: a full-screen web view that opens the PWA Launcher (which opens the Apps Script app inside it).
 * The launcher talks to this app through "TripNative" (only the launcher's own address may):
 * push token, call sound (earpiece / speaker, screen off at the ear), saving to the Gallery, opening a notification.
 */
public class MainActivity extends Activity {
    static MainActivity live;
    static boolean foreground;

    private static final int REQ_FILE = 11, REQ_MEDIA = 12, REQ_GEO = 13, REQ_NOTIF = 14, REQ_CAM = 15, REQ_LOC = 16;

    private WebView web;
    private FrameLayout root;
    private View fullView;
    private WebChromeClient.CustomViewCallback fullCb;
    private JavaScriptReplyProxy reply;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingMedia;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeo;
    private CallAudio audio;
    private MediaSaver saver;
    private String pendingGo, pendingMsg;
    private boolean helloSeen, oldWarned;
    private android.os.CancellationSignal bioCancel;
    private WebChromeClient.FileChooserParams pendingChooser;
    private Uri camPhoto, camVideo;
    private java.io.File camPhotoFile, camVideoFile;
    private View nearCover;
    private boolean locWanted;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        live = this;
        audio = new CallAudio(this, this::near);
        saver = new MediaSaver(this);
        CallNotifier.channels(this);

        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        fitBars();

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setGeolocationEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setSupportMultipleWindows(false);
        ws.setUserAgentString(ws.getUserAgentString() + " TripApp/" + BuildConfig.VERSION_NAME);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "TripNative", Collections.singleton(origin(BuildConfig.LAUNCHER_URL)),
                (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                    if (!isMainFrame) return;
                    reply = replyProxy;
                    onBridge(message.getData());
                });
        }
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());

        askNotifications();
        open(getIntent(), true);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        open(i, false);
    }

    @Override protected void onResume() { super.onResume(); foreground = true; }
    @Override protected void onPause() { super.onPause(); foreground = false; }

    @Override
    protected void onDestroy() {
        if (live == this) live = null;
        audio.stop();
        if (locWanted) stopService(new Intent(this, LocationService.class));
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (fullView != null) { hideFull(); return; }
        if (web.canGoBack()) web.goBack(); else moveTaskToBack(true);
    }

    /* start, or a tapped notification / "Answer" on the call screen */
    private void open(Intent i, boolean first) {
        String go = i != null ? i.getStringExtra("go") : null;
        boolean ans = i != null && i.getBooleanExtra("answer", false);
        if (go != null && go.startsWith("call:")) CallNotifier.cancel(this, go);
        if (!first && go != null && reply != null) {
            try {
                JSONObject o = new JSONObject();
                o.put("t", "go"); o.put("go", go); o.put("msg", ans ? "answer" : "");
                reply.postMessage(o.toString());
                return;
            } catch (Exception ignored) { }
        }
        if (!first && go == null) return;
        String url = BuildConfig.LAUNCHER_URL;
        if (go != null) {
            try {
                url += (url.contains("?") ? "&" : "?") + "go=" + URLEncoder.encode(go, "UTF-8") + (ans ? "&gm=answer" : "");
            } catch (Exception ignored) { }
        }
        web.loadUrl(url);
    }

    /* ---------- messages from the launcher ---------- */
    private void onBridge(String raw) {
        try {
            JSONObject m = new JSONObject(raw);
            String t = m.optString("t");
            switch (t) {
                case "hello": helloSeen = true; sendHello(); break;
                case "speaker": audio.setSpeaker(m.optBoolean("on")); break;
                case "call":
                    if ("live".equals(m.optString("st"))) {
                        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        audio.start(m.optBoolean("video"));
                    } else {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        audio.stop();
                    }
                    CallNotifier.cancelAllCalls(this);
                    break;
                case "ringStop": CallNotifier.cancelAllCalls(this); break;
                case "bio": bio(m.optString("op"), m.optInt("n")); break;
                case "loc": loc(m.optBoolean("on")); break;
                case "bioStop": if (bioCancel != null) { bioCancel.cancel(); bioCancel = null; } break;
                case "saveBegin": saver.begin(m.optString("id"), m.optString("name"), m.optString("mime"), m.optBoolean("media")); break;
                case "saveChunk": saver.chunk(m.optString("id"), m.optString("b64")); break;
                case "saveEnd":
                    final String id = m.optString("id");
                    saver.end(id, ok -> send("{\"t\":\"saved\",\"id\":" + JSONObject.quote(id) + ",\"ok\":" + ok + "}"));
                    break;
                default: break;
            }
        } catch (Exception ignored) { }
    }

    private void sendHello() {
        String tok = getSharedPreferences("trip", MODE_PRIVATE).getString("token", "");
        send(hello("hello", tok));
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                String t = task.getResult();
                getSharedPreferences("trip", MODE_PRIVATE).edit().putString("token", t).apply();
                send(hello("token", t));
            }
        });
    }

    private String hello(String t, String tok) {
        try {
            JSONObject o = new JSONObject();
            o.put("t", t); o.put("platform", "android"); o.put("token", tok); o.put("version", BuildConfig.VERSION_NAME); o.put("bio", true); o.put("loc", true);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    /* ---------- fingerprint / face unlock for the App lock ----------
       The web view has no WebAuthn, so the launcher asks the app: the phone's own fingerprint / face screen. */
    private void bio(String op, int n) {
        android.hardware.biometrics.BiometricManager bm = getSystemService(android.hardware.biometrics.BiometricManager.class);
        int kinds = android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_STRONG
            | android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK;
        int can = bm == null ? -1 : (Build.VERSION.SDK_INT >= 30 ? bm.canAuthenticate(kinds) : bm.canAuthenticate());
        if (can != android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS) {
            bioReply(n, false, can == android.hardware.biometrics.BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ? "noneEnrolled" : "unsupported", null);
            return;
        }
        if (bioCancel != null) bioCancel.cancel();
        final android.os.CancellationSignal cs = new android.os.CancellationSignal();
        bioCancel = cs;
        android.hardware.biometrics.BiometricPrompt.Builder b = new android.hardware.biometrics.BiometricPrompt.Builder(this)
            .setTitle(getString("new".equals(op) ? R.string.bio_new : R.string.bio_get))
            .setSubtitle(getString(R.string.app_name))
            .setConfirmationRequired(false)
            .setNegativeButton(getString(R.string.bio_pin), getMainExecutor(), (d, w) -> { if (bioCancel == cs) bioCancel = null; bioReply(n, false, "cancel", null); });
        if (Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(kinds);
        b.build().authenticate(cs, getMainExecutor(), new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult r) {
                if (bioCancel == cs) bioCancel = null;
                bioReply(n, true, null, "new".equals(op) ? randomId() : null);
            }
            @Override
            public void onAuthenticationError(int code, CharSequence msg) {
                if (bioCancel == cs) bioCancel = null;
                boolean cancel = code == android.hardware.biometrics.BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                    || code == android.hardware.biometrics.BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                    || code == 13 /* BIOMETRIC_ERROR_NEGATIVE_BUTTON (not public in the SDK) */;
                bioReply(n, false, cancel ? "cancel" : "NotAllowedError", null);
            }
        });
    }

    private void bioReply(int n, boolean ok, String err, String id) {
        try {
            JSONObject o = new JSONObject();
            o.put("t", "bio"); o.put("n", n); o.put("ok", ok);
            if (err != null) o.put("err", err);
            if (id != null) o.put("id", id);
            send(o.toString());
        } catch (Exception ignored) { }
    }

    private static String randomId() {
        byte[] b = new byte[24];
        new java.security.SecureRandom().nextBytes(b);
        return android.util.Base64.encodeToString(b, android.util.Base64.URL_SAFE | android.util.Base64.NO_PADDING | android.util.Base64.NO_WRAP);
    }

    /** a new push token (from PushService) */
    void tokenChanged(String tok) { runOnUiThread(() -> send(hello("token", tok))); }

    private void send(String json) {
        runOnUiThread(() -> { try { if (reply != null) reply.postMessage(json); } catch (Exception ignored) { } });
    }

    /* ---------- permissions ---------- */
    private void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else askFullScreen();
    }

    /* Android 14+: the user allows full-screen calls once */
    private void askFullScreen() {
        if (Build.VERSION.SDK_INT < 34) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null || nm.canUseFullScreenIntent()) return;
        if (getSharedPreferences("trip", MODE_PRIVATE).getBoolean("fsiAsked", false)) return;
        getSharedPreferences("trip", MODE_PRIVATE).edit().putBoolean("fsiAsked", true).apply();
        new AlertDialog.Builder(this).setTitle(R.string.fsi_t).setMessage(R.string.fsi_d)
            .setPositiveButton(R.string.ok, (d, w) -> {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { }
            })
            .setNegativeButton(R.string.later, null).show();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_NOTIF) { askFullScreen(); return; }
        if (req == REQ_CAM) { if (pendingChooser != null && fileCb != null) chooser(pendingChooser); return; }
        if (req == REQ_LOC) { if (locWanted && (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION))) loc(true); else if (locWanted) locErr("denied"); return; }
        if (req == REQ_MEDIA && pendingMedia != null) {
            List<String> ok = new ArrayList<>();
            for (String r : pendingMedia.getResources()) {
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) ok.add(r);
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) ok.add(r);
            }
            if (ok.isEmpty()) pendingMedia.deny(); else pendingMedia.grant(ok.toArray(new String[0]));
            pendingMedia = null;
        }
        if (req == REQ_GEO && pendingGeo != null) {
            pendingGeo.invoke(pendingGeoOrigin, has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION), false);
            pendingGeo = null;
        }
    }

    private boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || fileCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                out = new Uri[n];
                for (int k = 0; k < n; k++) out[k] = data.getClipData().getItemAt(k).getUri();
            } else if (data.getData() != null) out = new Uri[]{data.getData()};
        }
        /* the camera writes into our own file and often returns no data */
        if (res == RESULT_OK && out == null) {
            if (camPhotoFile != null && camPhotoFile.length() > 0) out = new Uri[]{camPhoto};
            else if (camVideoFile != null && camVideoFile.length() > 0) out = new Uri[]{camVideo};
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
    }

    /* ---------- choosing a file: the camera (photo / video) or the files / gallery ---------- */
    private static boolean accepts(WebChromeClient.FileChooserParams p, String kind) {
        String[] a = p.getAcceptTypes();
        boolean any = true;
        if (a != null) for (String t : a) {
            if (t == null || t.trim().isEmpty()) continue;
            any = false;
            for (String one : t.split(",")) {
                one = one.trim().toLowerCase();
                if (one.startsWith(kind) || one.equals("*/*") || (kind.equals("image/") && (one.endsWith(".jpg") || one.endsWith(".jpeg") || one.endsWith(".png") || one.endsWith(".heic"))))
                    return true;
            }
        }
        return any;
    }

    private Intent camIntent(boolean video) {
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "shots");
            if (!dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, (video ? "VID_" : "IMG_") + System.currentTimeMillis() + (video ? ".mp4" : ".jpg"));
            Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent i = new Intent(video ? android.provider.MediaStore.ACTION_VIDEO_CAPTURE : android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, u);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (video) { camVideo = u; camVideoFile = f; } else { camPhoto = u; camPhotoFile = f; }
            return i;
        } catch (Exception e) { return null; }
    }

    private boolean chooser(WebChromeClient.FileChooserParams p) {
        try {
            camPhoto = camVideo = null; camPhotoFile = camVideoFile = null;
            List<Intent> cams = new ArrayList<>();
            if (has(Manifest.permission.CAMERA)) {
                if (accepts(p, "image/")) { Intent c = camIntent(false); if (c != null) cams.add(c); }
                if (accepts(p, "video/")) { Intent c = camIntent(true); if (c != null) cams.add(c); }
            }
            /* <input capture>: straight to the camera */
            if (p.isCaptureEnabled() && !cams.isEmpty()) {
                startActivityForResult(cams.get(0), REQ_FILE);
                return true;
            }
            Intent i = p.createIntent();
            if (p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            Intent ch = Intent.createChooser(i, null);
            if (!cams.isEmpty()) ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, cams.toArray(new Intent[0]));
            startActivityForResult(ch, REQ_FILE);
            return true;
        } catch (Exception e) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = null;
            return false;
        }
    }

    /* ---------- the phone at the ear: black screen, touches blocked (when the system's own screen-off does not work) ---------- */
    private void near(boolean on) {
        runOnUiThread(() -> {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            if (on) {
                if (nearCover == null) {
                    nearCover = new View(this);
                    nearCover.setBackgroundColor(0xFF000000);
                    nearCover.setClickable(true);
                    nearCover.setOnTouchListener((v, e) -> true);
                    getWindow().addContentView(nearCover, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                }
                lp.screenBrightness = 0.01f;
                if (Build.VERSION.SDK_INT >= 30) getWindow().getInsetsController().hide(android.view.WindowInsets.Type.systemBars());
            } else {
                if (nearCover != null) { ((ViewGroup) nearCover.getParent()).removeView(nearCover); nearCover = null; }
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                if (Build.VERSION.SDK_INT >= 30) getWindow().getInsetsController().show(android.view.WindowInsets.Type.systemBars());
            }
            getWindow().setAttributes(lp);
        });
    }

    /* ---------- live location that keeps going with the screen locked (a foreground service) ---------- */
    private void loc(boolean on) {
        locWanted = on;
        if (!on) { stopService(new Intent(this, LocationService.class)); return; }
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION) && !has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        try {
            Intent i = new Intent(this, LocationService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) { locErr("error"); }
    }

    private void locErr(String why) { send("{\"t\":\"locErr\",\"error\":" + JSONObject.quote(why) + "}"); }

    /** a new position from LocationService */
    void locPos(android.location.Location l) {
        try {
            JSONObject o = new JSONObject();
            o.put("t", "loc"); o.put("lat", l.getLatitude()); o.put("lng", l.getLongitude()); o.put("acc", l.hasAccuracy() ? l.getAccuracy() : 50);
            if (l.hasSpeed()) o.put("speed", l.getSpeed());
            if (l.hasBearing()) o.put("heading", l.getBearing());
            send(o.toString());
        } catch (Exception ignored) { }
    }

    /* ---------- web view ---------- */
    /* Android 15 draws every app under the status bar and the 3-button bar ("edge-to-edge").
       Keep the page inside the free area (and above the keyboard), on every Android version the same way. */
    private void fitBars() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(0x00000000);
        getWindow().setNavigationBarColor(0x00000000);
        root.setBackgroundColor(0xFFFFFFFF);
        WindowInsetsControllerCompat bars = WindowCompat.getInsetsController(getWindow(), root);
        bars.setAppearanceLightStatusBars(true);
        bars.setAppearanceLightNavigationBars(true);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, ins) -> {
            if (fullView != null) { v.setPadding(0, 0, 0, 0); return WindowInsetsCompat.CONSUMED; }
            Insets b = ins.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    static String origin(String url) {
        Uri u = Uri.parse(url);
        return u.getScheme() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
    }

    private static boolean ours(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost();
        String lh = Uri.parse(BuildConfig.LAUNCHER_URL).getHost();
        return h.equals(lh) || h.equals("script.google.com") || h.endsWith(".googleusercontent.com") || h.equals("accounts.google.com");
    }

    private class Client extends WebViewClient {
        /* The launcher of 1.1.36 or newer says "hello" at once. If it does not, the launcher on the website is an old copy:
           the speaker button, saving to the Gallery and the push token cannot work until it is updated. */
        @Override
        public void onPageFinished(WebView v, String url) {
            if (helloSeen || oldWarned || url == null || !url.startsWith(origin(BuildConfig.LAUNCHER_URL))) return;
            v.postDelayed(() -> {
                if (helloSeen || oldWarned || isFinishing()) return;
                oldWarned = true;
                android.widget.Toast.makeText(MainActivity.this, R.string.old_launcher, android.widget.Toast.LENGTH_LONG).show();
            }, 6000);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String s = u.getScheme() == null ? "" : u.getScheme();
            if (("https".equals(s) || "http".equals(s)) && ours(u)) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
            return true;
        }
    }

    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(PermissionRequest r) {
            runOnUiThread(() -> {
                if (!ours(r.getOrigin())) { r.deny(); return; }
                List<String> need = new ArrayList<>();
                for (String res : r.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                }
                if (need.isEmpty()) { r.grant(r.getResources()); return; }
                pendingMedia = r;
                requestPermissions(need.toArray(new String[0]), REQ_MEDIA);
            });
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) { cb.invoke(origin, true, false); return; }
            pendingGeo = cb; pendingGeoOrigin = origin;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            pendingChooser = p;
            /* a photo of a receipt: the camera needs its permission first (else Android refuses to open it) */
            if ((accepts(p, "image/") || accepts(p, "video/")) && !has(Manifest.permission.CAMERA)) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
                return true;
            }
            return chooser(p);
        }

        /* a video's own "full screen" button */
        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            fullView = view; fullCb = cb;
            root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            ViewCompat.requestApplyInsets(root);
        }

        @Override
        public void onHideCustomView() { hideFull(); }
    }

    private void hideFull() {
        if (fullView == null) return;
        root.removeView(fullView);
        fullView = null;
        ViewCompat.requestApplyInsets(root);
        if (fullCb != null) { try { fullCb.onCustomViewHidden(); } catch (Exception ignored) { } fullCb = null; }
    }
}
