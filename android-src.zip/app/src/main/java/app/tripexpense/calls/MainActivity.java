package app.tripexpense.calls;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The app: a full-screen web view that opens the PWA Launcher (which opens the Apps Script app inside it).
 * The launcher talks to this app through "TripNative" (only the launcher's own address may):
 * push token, call sound (earpiece / speaker, screen off at the ear), saving to the Gallery, opening a notification.
 */
public class MainActivity extends Activity {
    static MainActivity live;
    static boolean foreground;

    private static final int REQ_FILE = 11, REQ_MEDIA = 12, REQ_GEO = 13, REQ_NOTIF = 14;

    private WebView web;
    private FrameLayout root;
    private View fullView;
    private WebChromeClient.CustomViewCallback fullCb;
    private JavaScriptReplyProxy reply;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingMedia;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeo;
    private CallAudio audio;
    private MediaSaver saver;
    private String pendingGo, pendingMsg;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        live = this;
        audio = new CallAudio(this);
        saver = new MediaSaver(this);
        CallNotifier.channels(this);

        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setGeolocationEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setSupportMultipleWindows(false);
        ws.setUserAgentString(ws.getUserAgentString() + " TripApp/" + BuildConfig.VERSION_NAME);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "TripNative", Collections.singleton(origin(BuildConfig.LAUNCHER_URL)),
                (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                    if (!isMainFrame) return;
                    reply = replyProxy;
                    onBridge(message.getData());
                });
        }
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());

        askNotifications();
        open(getIntent(), true);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        open(i, false);
    }

    @Override protected void onResume() { super.onResume(); foreground = true; }
    @Override protected void onPause() { super.onPause(); foreground = false; }

    @Override
    protected void onDestroy() {
        if (live == this) live = null;
        audio.stop();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (fullView != null) { hideFull(); return; }
        if (web.canGoBack()) web.goBack(); else moveTaskToBack(true);
    }

    /* start, or a tapped notification / "Answer" on the call screen */
    private void open(Intent i, boolean first) {
        String go = i != null ? i.getStringExtra("go") : null;
        boolean ans = i != null && i.getBooleanExtra("answer", false);
        if (go != null && go.startsWith("call:")) CallNotifier.cancel(this, go);
        if (!first && go != null && reply != null) {
            try {
                JSONObject o = new JSONObject();
                o.put("t", "go"); o.put("go", go); o.put("msg", ans ? "answer" : "");
                reply.postMessage(o.toString());
                return;
            } catch (Exception ignored) { }
        }
        if (!first && go == null) return;
        String url = BuildConfig.LAUNCHER_URL;
        if (go != null) {
            try {
                url += (url.contains("?") ? "&" : "?") + "go=" + URLEncoder.encode(go, "UTF-8") + (ans ? "&gm=answer" : "");
            } catch (Exception ignored) { }
        }
        web.loadUrl(url);
    }

    /* ---------- messages from the launcher ---------- */
    private void onBridge(String raw) {
        try {
            JSONObject m = new JSONObject(raw);
            String t = m.optString("t");
            switch (t) {
                case "hello": sendHello(); break;
                case "speaker": audio.setSpeaker(m.optBoolean("on")); break;
                case "call":
                    if ("live".equals(m.optString("st"))) {
                        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        audio.start(m.optBoolean("video"));
                    } else {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        audio.stop();
                    }
                    CallNotifier.cancelAllCalls(this);
                    break;
                case "ringStop": CallNotifier.cancelAllCalls(this); break;
                case "saveBegin": saver.begin(m.optString("id"), m.optString("name"), m.optString("mime"), m.optBoolean("media")); break;
                case "saveChunk": saver.chunk(m.optString("id"), m.optString("b64")); break;
                case "saveEnd":
                    final String id = m.optString("id");
                    saver.end(id, ok -> send("{\"t\":\"saved\",\"id\":" + JSONObject.quote(id) + ",\"ok\":" + ok + "}"));
                    break;
                default: break;
            }
        } catch (Exception ignored) { }
    }

    private void sendHello() {
        String tok = getSharedPreferences("trip", MODE_PRIVATE).getString("token", "");
        send(hello("hello", tok));
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                String t = task.getResult();
                getSharedPreferences("trip", MODE_PRIVATE).edit().putString("token", t).apply();
                send(hello("token", t));
            }
        });
    }

    private String hello(String t, String tok) {
        try {
            JSONObject o = new JSONObject();
            o.put("t", t); o.put("platform", "android"); o.put("token", tok); o.put("version", BuildConfig.VERSION_NAME);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    /** a new push token (from PushService) */
    void tokenChanged(String tok) { runOnUiThread(() -> send(hello("token", tok))); }

    private void send(String json) {
        runOnUiThread(() -> { try { if (reply != null) reply.postMessage(json); } catch (Exception ignored) { } });
    }

    /* ---------- permissions ---------- */
    private void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else askFullScreen();
    }

    /* Android 14+: the user allows full-screen calls once */
    private void askFullScreen() {
        if (Build.VERSION.SDK_INT < 34) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null || nm.canUseFullScreenIntent()) return;
        if (getSharedPreferences("trip", MODE_PRIVATE).getBoolean("fsiAsked", false)) return;
        getSharedPreferences("trip", MODE_PRIVATE).edit().putBoolean("fsiAsked", true).apply();
        new AlertDialog.Builder(this).setTitle(R.string.fsi_t).setMessage(R.string.fsi_d)
            .setPositiveButton(R.string.ok, (d, w) -> {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { }
            })
            .setNegativeButton(R.string.later, null).show();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_NOTIF) { askFullScreen(); return; }
        if (req == REQ_MEDIA && pendingMedia != null) {
            List<String> ok = new ArrayList<>();
            for (String r : pendingMedia.getResources()) {
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) ok.add(r);
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) ok.add(r);
            }
            if (ok.isEmpty()) pendingMedia.deny(); else pendingMedia.grant(ok.toArray(new String[0]));
            pendingMedia = null;
        }
        if (req == REQ_GEO && pendingGeo != null) {
            pendingGeo.invoke(pendingGeoOrigin, has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION), false);
            pendingGeo = null;
        }
    }

    private boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || fileCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                out = new Uri[n];
                for (int k = 0; k < n; k++) out[k] = data.getClipData().getItemAt(k).getUri();
            } else if (data.getData() != null) out = new Uri[]{data.getData()};
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
    }

    /* ---------- web view ---------- */
    static String origin(String url) {
        Uri u = Uri.parse(url);
        return u.getScheme() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
    }

    private static boolean ours(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost();
        String lh = Uri.parse(BuildConfig.LAUNCHER_URL).getHost();
        return h.equals(lh) || h.equals("script.google.com") || h.endsWith(".googleusercontent.com") || h.equals("accounts.google.com");
    }

    private class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String s = u.getScheme() == null ? "" : u.getScheme();
            if (("https".equals(s) || "http".equals(s)) && ours(u)) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
            return true;
        }
    }

    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(PermissionRequest r) {
            runOnUiThread(() -> {
                if (!ours(r.getOrigin())) { r.deny(); return; }
                List<String> need = new ArrayList<>();
                for (String res : r.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                }
                if (need.isEmpty()) { r.grant(r.getResources()); return; }
                pendingMedia = r;
                requestPermissions(need.toArray(new String[0]), REQ_MEDIA);
            });
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) { cb.invoke(origin, true, false); return; }
            pendingGeo = cb; pendingGeoOrigin = origin;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                Intent i = p.createIntent();
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(i, null), REQ_FILE);
                return true;
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
        }

        /* a video's own "full screen" button */
        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            fullView = view; fullCb = cb;
            root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        @Override
        public void onHideCustomView() { hideFull(); }
    }

    private void hideFull() {
        if (fullView == null) return;
        root.removeView(fullView);
        fullView = null;
        if (fullCb != null) { try { fullCb.onCustomViewHidden(); } catch (Exception ignored) { } fullCb = null; }
    }
}
