package app.tripexpense.calls;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.service.notification.StatusBarNotification;

import androidx.core.app.NotificationCompat;
import androidx.core.app.Person;

/**
 * Notifications of the app.
 * A ringing call: a full-screen call screen over the lock screen (CallActivity), the phone's ringtone repeated
 * until it is answered, declined, missed (the server's "Missed call" alert) or after 45 seconds.
 */
final class CallNotifier {
    static final String CH_CALLS = "calls2", CH_MSGS = "messages";
    private static final long[] VIBRATE = {0, 800, 600, 800, 600, 800};

    private CallNotifier() { }

    static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel calls = new NotificationChannel(CH_CALLS, c.getString(R.string.ch_calls), NotificationManager.IMPORTANCE_HIGH);
        calls.setDescription(c.getString(R.string.ch_calls_d));
        Uri tone = RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_RINGTONE);
        if (tone == null) tone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        calls.setSound(tone, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        calls.enableVibration(true);
        calls.setVibrationPattern(VIBRATE);
        calls.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        calls.setBypassDnd(true);
        nm.createNotificationChannel(calls);
        NotificationChannel msgs = new NotificationChannel(CH_MSGS, c.getString(R.string.ch_msgs), NotificationManager.IMPORTANCE_HIGH);
        msgs.setDescription(c.getString(R.string.ch_msgs_d));
        nm.createNotificationChannel(msgs);
    }

    static boolean isVideo(String title, String body) { return (title != null && title.startsWith("📹")) || (body != null && body.toLowerCase().contains("video")); }

    static int idOf(String go) { return go == null ? 1 : (go.hashCode() & 0x7fffffff) | 1; }

    private static PendingIntent openApp(Context c, String go, boolean answer, int req) { return openApp(c, go, answer, req, null, null); }

    private static PendingIntent openApp(Context c, String go, boolean answer, int req, String title, String body) {
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("go", go).putExtra("answer", answer);
        if (title != null) i.putExtra("cname", clean(title)).putExtra("cvideo", isVideo(title, body));
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** an incoming call */
    static void ring(Context c, String go, String title, String body) {
        channels(c);
        int id = idOf(go);
        Intent full = new Intent(c, CallActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION)
            .putExtra("go", go).putExtra("title", title).putExtra("body", body);
        PendingIntent fullPi = PendingIntent.getActivity(c, id, full, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent answer = openApp(c, go, true, id + 1, title, body);
        PendingIntent decline = PendingIntent.getBroadcast(c, id + 2, new Intent(c, DeclineReceiver.class).putExtra("go", go),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Person caller = new Person.Builder().setName(clean(title)).setImportant(true).build();
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_CALLS)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(clean(title))
            .setContentText(body == null || body.isEmpty() ? c.getString(R.string.incoming) : body)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullPi, true)
            .setContentIntent(fullPi)
            .setOngoing(true)
            .setAutoCancel(false)
            .setTimeoutAfter(45000)
            .setVibrate(VIBRATE)
            .setStyle(NotificationCompat.CallStyle.forIncomingCall(caller, decline, answer));
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT; // the ringtone repeats until the call is answered / ends
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        try { if (nm != null) nm.notify(id, n); } catch (SecurityException ignored) { }
        wake(c);
    }

    /* 1.1.42: light up the screen for a ringing call. Android 14+ shows the full-screen call screen only when
       "full-screen notifications" are allowed for the app (Samsung often has it off); without it the call would only
       be a small alert on a dark screen. The screen stays on while it rings (at most 45 s), like a phone call. */
    private static PowerManager.WakeLock ringWake;
    @SuppressWarnings("deprecation")
    private static void wake(Context c) {
        try {
            PowerManager pm = c.getSystemService(PowerManager.class);
            if (pm == null) return;
            if (ringWake != null && ringWake.isHeld()) ringWake.release();
            ringWake = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "trip:ring");
            ringWake.setReferenceCounted(false);
            ringWake.acquire(45000);
        } catch (Exception ignored) { }
    }

    static void unwake() {
        try { if (ringWake != null && ringWake.isHeld()) ringWake.release(); } catch (Exception ignored) { }
        ringWake = null;
    }

    /** Android 14+: may this app show a call full screen over the lock screen? (older Android: always) */
    static boolean fullScreenOk(Context c) {
        if (Build.VERSION.SDK_INT < 34) return true;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        try { return nm == null || nm.canUseFullScreenIntent(); } catch (Exception e) { return true; }
    }

    /** a chat message, a missed call, … */
    static void message(Context c, String go, String title, String body, String tag) {
        channels(c);
        int id = tag == null || tag.isEmpty() ? (int) (System.currentTimeMillis() & 0x7ffffff) : (tag.hashCode() & 0x7fffffff);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_MSGS)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(clean(title))
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp(c, go, false, id));
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        try { if (nm != null) nm.notify(id, b.build()); } catch (SecurityException ignored) { }
    }

    static void cancel(Context c, String go) {
        stopRinging(c, go);
        CallActivity.closeFor(go);
    }

    /** only the ringing notification (the call screen stays, e.g. while the phone unlocks) */
    static void stopRinging(Context c, String go) {
        unwake();
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(idOf(go));
    }

    static void cancelAllCalls(Context c) {
        unwake();
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        for (StatusBarNotification s : nm.getActiveNotifications()) {
            if (CH_CALLS.equals(s.getNotification().getChannelId())) nm.cancel(s.getId());
        }
        CallActivity.closeFor(null);
    }

    private static String clean(String t) {
        String s = t == null ? "" : t.replaceAll("^[\\p{So}\\s]+", "").trim();
        return s.isEmpty() ? "Trip Expense" : s;
    }
}
