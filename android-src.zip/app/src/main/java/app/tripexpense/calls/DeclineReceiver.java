package app.tripexpense.calls;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** "Decline" on the call notification: stop ringing (the caller then sees "No answer" when the call times out). */
public class DeclineReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        CallNotifier.cancel(c, i.getStringExtra("go"));
    }
}
