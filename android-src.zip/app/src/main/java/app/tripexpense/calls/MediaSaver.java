package app.tripexpense.calls;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Saves a photo / video straight into the Gallery (Pictures/Trip Expense, Movies/Trip Expense),
 * other files into Downloads. The launcher sends the file in pieces (base64).
 */
class MediaSaver {
    interface Done { void done(boolean ok); }

    private static class Job { File tmp; OutputStream out; String name, mime; boolean media; }

    private final Context ctx;
    private final Map<String, Job> jobs = new HashMap<>();
    private final Handler main = new Handler(Looper.getMainLooper());

    MediaSaver(Context c) { ctx = c.getApplicationContext(); }

    synchronized void begin(String id, String name, String mime, boolean media) {
        try {
            Job j = new Job();
            j.name = clean(name); j.mime = mime == null || mime.isEmpty() ? "application/octet-stream" : mime; j.media = media;
            j.tmp = File.createTempFile("save", ".part", ctx.getCacheDir());
            j.out = new FileOutputStream(j.tmp);
            jobs.put(id, j);
        } catch (Exception ignored) { }
    }

    synchronized void chunk(String id, String b64) {
        Job j = jobs.get(id);
        if (j == null) return;
        try { j.out.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { drop(id); }
    }

    void end(String id, Done cb) {
        final Job j;
        synchronized (this) { j = jobs.remove(id); }
        if (j == null) { cb.done(false); return; }
        new Thread(() -> {
            boolean ok = false;
            try {
                j.out.close();
                ok = store(j);
            } catch (Exception ignored) { }
            j.tmp.delete();
            final boolean r = ok;
            main.post(() -> cb.done(r));
        }).start();
    }

    private synchronized void drop(String id) {
        Job j = jobs.remove(id);
        if (j == null) return;
        try { j.out.close(); } catch (Exception ignored) { }
        j.tmp.delete();
    }

    private boolean store(Job j) throws Exception {
        boolean img = j.mime.startsWith("image/"), vid = j.mime.startsWith("video/");
        Uri coll;
        String dir;
        if (j.media && img) { coll = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); dir = Environment.DIRECTORY_PICTURES; }
        else if (j.media && vid) { coll = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); dir = Environment.DIRECTORY_MOVIES; }
        else { coll = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); dir = Environment.DIRECTORY_DOWNLOADS; }
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, j.name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, j.mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/Trip Expense");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        ContentResolver cr = ctx.getContentResolver();
        Uri item = cr.insert(coll, v);
        if (item == null) return false;
        try (InputStream in = new FileInputStream(j.tmp); OutputStream out = cr.openOutputStream(item)) {
            if (out == null) return false;
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(item, done, null, null);
        return true;
    }

    private static String clean(String n) {
        String s = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return s.isEmpty() ? "file" : (s.length() > 120 ? s.substring(0, 120) : s);
    }
}
