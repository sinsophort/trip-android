package app.tripexpense.calls;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Saves a photo / video straight into the Gallery (Pictures/Trip Expense, Movies/Trip Expense),
 * other files into Downloads. The launcher sends the file in pieces (base64).
 */
class MediaSaver {
    interface Done { void done(boolean ok, Uri item, String name, String mime, boolean media); }

    private static class Job { File tmp; OutputStream out; String name, mime; boolean media; }

    private final Context ctx;
    private final Map<String, Job> jobs = new HashMap<>();
    private final Handler main = new Handler(Looper.getMainLooper());

    MediaSaver(Context c) { ctx = c.getApplicationContext(); }

    synchronized void begin(String id, String name, String mime, boolean media) {
        try {
            Job j = new Job();
            j.name = clean(name); j.mime = mime == null || mime.isEmpty() ? "application/octet-stream" : mime; j.media = media;
            j.tmp = File.createTempFile("save", ".part", ctx.getCacheDir());
            j.out = new FileOutputStream(j.tmp);
            jobs.put(id, j);
        } catch (Exception ignored) { }
    }

    synchronized void chunk(String id, String b64) {
        Job j = jobs.get(id);
        if (j == null) return;
        try { j.out.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { drop(id); }
    }

    void end(String id, Done cb) {
        final Job j;
        synchronized (this) { j = jobs.remove(id); }
        if (j == null) { cb.done(false, null, null, null, false); return; }
        new Thread(() -> {
            Uri item = null;
            try {
                j.out.close();
                item = store(j);
            } catch (Exception ignored) { }
            j.tmp.delete();
            final Uri r = item;
            main.post(() -> cb.done(r != null, r, j.name, j.mime, j.media && (j.mime.startsWith("image/") || j.mime.startsWith("video/"))));
        }).start();
    }

    private synchronized void drop(String id) {
        Job j = jobs.remove(id);
        if (j == null) return;
        try { j.out.close(); } catch (Exception ignored) { }
        j.tmp.delete();
    }

    private Uri store(Job j) throws Exception {
        boolean img = j.mime.startsWith("image/"), vid = j.mime.startsWith("video/");
        Uri coll;
        String dir;
        if (j.media && img) { coll = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); dir = Environment.DIRECTORY_PICTURES; }
        else if (j.media && vid) { coll = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); dir = Environment.DIRECTORY_MOVIES; }
        /* 1.1.39: files (PDF, CSV, Excel …) straight into Download, where the Files app opens */
        else { coll = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); dir = Environment.DIRECTORY_DOWNLOADS; }
        boolean file = coll.equals(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY));
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, j.name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, j.mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, file ? dir : dir + "/Trip Expense");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        ContentResolver cr = ctx.getContentResolver();
        Uri item = cr.insert(coll, v);
        if (item == null) return null;
        try (InputStream in = new FileInputStream(j.tmp); OutputStream out = cr.openOutputStream(item)) {
            if (out == null) { cr.delete(item, null, null); return null; }
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(item, done, null, null);
        return item;
    }

    /* ---------- 1.1.39: "Saved to Downloads" notification: tap → the Downloads folder, "Open" → the file ---------- */
    static final String CH_FILES = "files";
    private static int noteId = 9100;

    static void notifySaved(Context c, Uri item, String name, String mime) {
        try {
            android.app.NotificationManager nm = c.getSystemService(android.app.NotificationManager.class);
            if (nm == null) return;
            if (android.os.Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
            android.app.NotificationChannel ch = new android.app.NotificationChannel(CH_FILES, c.getString(R.string.ch_files), android.app.NotificationManager.IMPORTANCE_DEFAULT);
            ch.setSound(null, null);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
            int id = ++noteId;
            android.content.Intent dl = new android.content.Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            android.app.PendingIntent tap = android.app.PendingIntent.getActivity(c, id, dl, android.app.PendingIntent.FLAG_IMMUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT);
            android.content.Intent view = new android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(item, mime)
                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            android.app.PendingIntent open = android.app.PendingIntent.getActivity(c, id + 50000, android.content.Intent.createChooser(view, name).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                android.app.PendingIntent.FLAG_IMMUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT);
            android.app.Notification n = new android.app.Notification.Builder(c, CH_FILES)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(c.getString(R.string.saved_t))
                .setContentText(name)
                .setSubText(c.getString(R.string.saved_where))
                .setContentIntent(tap)
                .setAutoCancel(true)
                .addAction(new android.app.Notification.Action.Builder(null, c.getString(R.string.open_file), open).build())
                .addAction(new android.app.Notification.Action.Builder(null, c.getString(R.string.open_downloads), tap).build())
                .build();
            nm.notify(id, n);
        } catch (Exception ignored) { }
    }

    private static String clean(String n) {
        String s = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return s.isEmpty() ? "file" : (s.length() > 120 ? s.substring(0, 120) : s);
    }
}
