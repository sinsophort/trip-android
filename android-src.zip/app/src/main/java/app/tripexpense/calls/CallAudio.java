package app.tripexpense.calls;

import android.content.Context;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.PowerManager;

import java.util.List;

/**
 * The sound of a call: the small earpiece (next to the front camera) or the loudspeaker.
 * With the earpiece, the screen turns off when the phone is at your ear (proximity sensor) and on again after.
 */
class CallAudio implements SensorEventListener {
    interface Near { void near(boolean on); }
    private final Near nearCb;
    private final SensorManager sm;
    private final Sensor ps;
    private boolean listening, isNear;
    private final Handler h = new Handler(Looper.getMainLooper());
    private AudioManager.OnCommunicationDeviceChangedListener devCb;
    private final AudioManager am;
    private final PowerManager.WakeLock prox;
    private boolean on, video, speaker;

    CallAudio(Context c, Near cb) {
        nearCb = cb;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        ps = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock w = null;
        try {
            if (pm != null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK))
                w = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "trip:ear");
        } catch (Exception ignored) { }
        prox = w;
    }

    /** a call is connected: voice → earpiece, video → loudspeaker */
    void start(boolean isVideo) {
        /* the same call again (it was "calling", now it is connected): keep the person's choice, only apply it again */
        if (on && video == isVideo) { route(); return; }
        on = true; video = isVideo;
        try { am.setMode(AudioManager.MODE_IN_COMMUNICATION); } catch (Exception ignored) { }
        setSpeaker(isVideo);
        /* the web page's call engine sets its own sound route a moment after it starts (often the loudspeaker):
           apply ours again a few times, and whenever Android reports another device */
        for (long ms : new long[]{300, 900, 2000, 4000, 7000}) h.postDelayed(this::route, ms);
        if (Build.VERSION.SDK_INT >= 31 && devCb == null) {
            devCb = d -> {
                if (!on || d == null) return;
                int want = speaker ? AudioDeviceInfo.TYPE_BUILTIN_SPEAKER : AudioDeviceInfo.TYPE_BUILTIN_EARPIECE;
                int t = d.getType();
                boolean builtIn = t == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER || t == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE;
                /* a headset / Bluetooth is the person's choice: leave it */
                if (builtIn && t != want) h.postDelayed(this::route, 120);
            };
            try { am.addOnCommunicationDeviceChangedListener(java.util.concurrent.Executors.newSingleThreadExecutor(), devCb); } catch (Exception ignored) { }
        }
    }

    private void route() { if (on) setSpeaker(speaker); }

    void setSpeaker(boolean wantSpeaker) {
        speaker = wantSpeaker;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                AudioDeviceInfo pick = null;
                List<AudioDeviceInfo> list = am.getAvailableCommunicationDevices();
                int want = wantSpeaker ? AudioDeviceInfo.TYPE_BUILTIN_SPEAKER : AudioDeviceInfo.TYPE_BUILTIN_EARPIECE;
                if (!wantSpeaker) for (AudioDeviceInfo d : list) {
                    int t = d.getType();
                    if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || t == AudioDeviceInfo.TYPE_BLE_HEADSET) { pick = d; break; }
                }
                if (pick == null) for (AudioDeviceInfo d : list) if (d.getType() == want) { pick = d; break; }
                if (pick != null) am.setCommunicationDevice(pick); else am.clearCommunicationDevice();
            } else {
                am.setSpeakerphoneOn(wantSpeaker);
            }
        } catch (Exception ignored) { }
        ear(on && !wantSpeaker && !video);
    }

    /** the call ended: back to normal */
    void stop() {
        h.removeCallbacksAndMessages(null);
        if (Build.VERSION.SDK_INT >= 31 && devCb != null) { try { am.removeOnCommunicationDeviceChangedListener(devCb); } catch (Exception ignored) { } devCb = null; }
        if (!on) return;
        on = false;
        ear(false);
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice(); else am.setSpeakerphoneOn(false);
            am.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception ignored) { }
    }

    /* screen off at the ear */
    private void ear(boolean want) {
        if (prox != null) {
            try {
                if (want && !prox.isHeld()) prox.acquire(4 * 60 * 60 * 1000L);
                else if (!want && prox.isHeld()) prox.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY);
            } catch (Exception ignored) { }
        }
        /* some phones (Samsung, Xiaomi …) ignore the screen-off lock for apps: watch the sensor ourselves too */
        if (sm == null || ps == null) return;
        if (want && !listening) { listening = sm.registerListener(this, ps, SensorManager.SENSOR_DELAY_NORMAL); }
        else if (!want && listening) { sm.unregisterListener(this); listening = false; setNear(false); }
    }

    private void setNear(boolean n) {
        if (n == isNear) return;
        isNear = n;
        if (nearCb != null) nearCb.near(n);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (ps == null || e.values == null || e.values.length == 0) return;
        float v = e.values[0], max = ps.getMaximumRange();
        setNear(v < Math.min(5f, max) && v < max);
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) { }

    boolean isSpeaker() { return speaker; }
}
