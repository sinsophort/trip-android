package app.tripexpense.calls;

import android.content.Context;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.PowerManager;

import java.util.List;

/**
 * The sound of a call: the small earpiece (next to the front camera) or the loudspeaker.
 * With the earpiece, the screen turns off when the phone is at your ear (proximity sensor) and on again after.
 */
class CallAudio {
    private final AudioManager am;
    private final PowerManager.WakeLock prox;
    private boolean on, video, speaker;

    CallAudio(Context c) {
        am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock w = null;
        try {
            if (pm != null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK))
                w = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "trip:ear");
        } catch (Exception ignored) { }
        prox = w;
    }

    /** a call is connected: voice → earpiece, video → loudspeaker */
    void start(boolean isVideo) {
        on = true; video = isVideo;
        try { am.setMode(AudioManager.MODE_IN_COMMUNICATION); } catch (Exception ignored) { }
        setSpeaker(isVideo);
    }

    void setSpeaker(boolean wantSpeaker) {
        speaker = wantSpeaker;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                AudioDeviceInfo pick = null;
                List<AudioDeviceInfo> list = am.getAvailableCommunicationDevices();
                int want = wantSpeaker ? AudioDeviceInfo.TYPE_BUILTIN_SPEAKER : AudioDeviceInfo.TYPE_BUILTIN_EARPIECE;
                for (AudioDeviceInfo d : list) if (d.getType() == want) { pick = d; break; }
                if (pick != null) am.setCommunicationDevice(pick); else am.clearCommunicationDevice();
            } else {
                am.setSpeakerphoneOn(wantSpeaker);
            }
        } catch (Exception ignored) { }
        ear(on && !wantSpeaker && !video);
    }

    /** the call ended: back to normal */
    void stop() {
        if (!on) return;
        on = false;
        ear(false);
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice(); else am.setSpeakerphoneOn(false);
            am.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception ignored) { }
    }

    /* screen off at the ear */
    private void ear(boolean want) {
        if (prox == null) return;
        try {
            if (want && !prox.isHeld()) prox.acquire(4 * 60 * 60 * 1000L);
            else if (!want && prox.isHeld()) prox.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY);
        } catch (Exception ignored) { }
    }

    boolean isSpeaker() { return speaker; }
}
