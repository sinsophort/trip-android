package app.tripexpense.calls;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import java.lang.ref.WeakReference;

/** The incoming call screen: shows over the lock screen, like a normal phone call. */
public class CallActivity extends Activity {
    private static WeakReference<CallActivity> current = new WeakReference<>(null);
    private String go;
    private final Handler h = new Handler(Looper.getMainLooper());

    /** the call was answered elsewhere, missed or ended: close this screen */
    static void closeFor(String go) {
        CallActivity a = current.get();
        if (a != null && (go == null || go.equals(a.go))) a.runOnUiThread(a::finish);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        current = new WeakReference<>(this);
        go = getIntent().getStringExtra("go");
        String title = getIntent().getStringExtra("title"), body = getIntent().getStringExtra("body");
        String name = title == null ? "" : title.replaceAll("^[\\p{So}\\s]+", "").trim();
        boolean video = (title != null && title.startsWith("📹")) || (body != null && body.contains("video"));

        float dp = getResources().getDisplayMetrics().density;
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, (int) (90 * dp), 0, (int) (60 * dp));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF334155, 0xFF0B1220});
        col.setBackground(bg);

        TextView av = new TextView(this);
        av.setText(name.isEmpty() ? "?" : name.substring(0, Math.min(2, name.length())).toUpperCase());
        av.setTextColor(Color.WHITE);
        av.setTextSize(36);
        av.setGravity(Gravity.CENTER);
        av.setBackgroundResource(R.drawable.avatar_bg);
        LinearLayout.LayoutParams avp = new LinearLayout.LayoutParams((int) (120 * dp), (int) (120 * dp));
        col.addView(av, avp);
        ScaleAnimation pulse = new ScaleAnimation(1f, 1.08f, 1f, 1.08f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
        pulse.setDuration(900); pulse.setRepeatMode(Animation.REVERSE); pulse.setRepeatCount(Animation.INFINITE);
        av.startAnimation(pulse);

        TextView nm = new TextView(this);
        nm.setText(name.isEmpty() ? getString(R.string.app_name) : name);
        nm.setTextColor(Color.WHITE); nm.setTextSize(28); nm.setGravity(Gravity.CENTER);
        nm.setPadding(0, (int) (24 * dp), 0, (int) (6 * dp));
        col.addView(nm);
        TextView sub = new TextView(this);
        sub.setText((video ? "📹 " : "📞 ") + getString(R.string.incoming));
        sub.setTextColor(0xCCFFFFFF); sub.setTextSize(16); sub.setGravity(Gravity.CENTER);
        col.addView(sub);

        View spacer = new View(this);
        col.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.addView(button(R.drawable.btn_decline, "✕", getString(R.string.decline), v -> decline(), dp));
        View gap = new View(this);
        row.addView(gap, new LinearLayout.LayoutParams((int) (90 * dp), 1));
        row.addView(button(R.drawable.btn_answer, video ? "📹" : "📞", getString(R.string.answer), v -> answer(), dp));
        col.addView(row);

        setContentView(col);
        /* Android 15 draws under the system bars: keep the Answer / Decline buttons above the 3-button bar */
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowCompat.getInsetsController(getWindow(), col).setAppearanceLightStatusBars(false);
        final int padTop = (int) (90 * dp), padBottom = (int) (60 * dp);
        ViewCompat.setOnApplyWindowInsetsListener(col, (v, ins) -> {
            Insets sb = ins.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(sb.left, padTop + sb.top, sb.right, padBottom + sb.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        /* nobody answered: the server's "Missed call" usually closes it first */
        h.postDelayed(this::finish, 45000);
    }

    private View button(int bgRes, String icon, String label, View.OnClickListener l, float dp) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView b = new TextView(this);
        b.setText(icon); b.setTextSize(30); b.setGravity(Gravity.CENTER); b.setTextColor(Color.WHITE);
        b.setBackgroundResource(bgRes);
        b.setOnClickListener(l);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams((int) (76 * dp), (int) (76 * dp));
        box.addView(b, new LinearLayout.LayoutParams(bp.width, bp.height));
        TextView t = new TextView(this);
        t.setText(label); t.setTextColor(Color.WHITE); t.setTextSize(14); t.setGravity(Gravity.CENTER);
        t.setPadding(0, (int) (8 * dp), 0, 0);
        box.addView(t);
        return box;
    }

    private void answer() {
        CallNotifier.stopRinging(this, go);
        Runnable open = () -> {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("go", go).putExtra("answer", true));
            finish();
        };
        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km != null && km.isKeyguardLocked()) {
            /* unlock first (PIN / fingerprint), then the call connects in the app */
            km.requestDismissKeyguard(this, new KeyguardManager.KeyguardDismissCallback() {
                @Override public void onDismissSucceeded() { open.run(); }
                @Override public void onDismissCancelled() { }
                @Override public void onDismissError() { open.run(); }
            });
        } else open.run();
    }

    private void decline() {
        CallNotifier.cancel(this, go);
        finish();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (current.get() == this) current = new WeakReference<>(null);
        super.onDestroy();
    }
}
