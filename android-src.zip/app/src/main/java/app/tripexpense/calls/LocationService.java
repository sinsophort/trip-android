package app.tripexpense.calls;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Live location: keeps getting the phone's position while the screen is locked or the app is in the background,
 * and hands every position to the launcher (which sends it to the server like before).
 * 1.1.39: with the screen locked Android freezes the web page, so the service also sends each position to the
 * server itself (the app's address + a ticket that only allows "my position in this chat, until the sharing ends").
 * Android shows a small "Sharing your live location" notification while it runs.
 */
public class LocationService extends Service implements LocationListener {
    private static final String CH_LOC = "live_loc";
    private static final int ID = 7301;
    private LocationManager lm;
    private PowerManager.WakeLock cpu;
    private Location last, sent;
    private long sentAt, until;
    private boolean busy;
    private String postUrl, ticket;
    private final android.os.Handler h = new android.os.Handler(Looper.getMainLooper());
    private final java.util.concurrent.ExecutorService net = java.util.concurrent.Executors.newSingleThreadExecutor();
    /* still standing: send the same position again now and then, so the others see it is fresh */
    private final Runnable endR = this::endNow;
    private final Runnable beat = new Runnable() { @Override public void run() { if (last != null && System.currentTimeMillis() - sentAt > 24000) post(last, true); h.postDelayed(this, 25000); } };

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH_LOC, getString(R.string.ch_loc), NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("url")) {
            postUrl = intent.getStringExtra("url"); ticket = intent.getStringExtra("ticket"); until = intent.getLongExtra("until", 0);
            if (postUrl != null && postUrl.isEmpty()) { postUrl = null; ticket = null; until = 0; }
            sent = null; sentAt = 0;
            h.removeCallbacks(beat); h.postDelayed(beat, 25000);
            h.removeCallbacks(endR);
            if (until > 0) h.postDelayed(endR, Math.max(1000, until - System.currentTimeMillis() + 3000));
            else h.removeCallbacks(beat);
            if (last != null) post(last, true);
        }
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CH_LOC)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(getString(R.string.loc_t))
            .setContentText(getString(R.string.loc_d))
            .setOngoing(true)
            .setContentIntent(pi)
            .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(ID, n);
        } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }

        if (cpu == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            if (pm != null) { cpu = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "trip:loc"); cpu.setReferenceCounted(false); }
        }
        /* keep the app's page awake enough to send the positions; at most 12 h (sharing lasts at most 8 h) */
        try { if (cpu != null && !cpu.isHeld()) cpu.acquire(12 * 60 * 60 * 1000L); } catch (Exception ignored) { }

        if (lm == null) {
            lm = getSystemService(LocationManager.class);
            try {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 4000, 0, this, Looper.getMainLooper());
            } catch (SecurityException | IllegalArgumentException ignored) { }
            try {
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000, 5, this, Looper.getMainLooper());
            } catch (SecurityException | IllegalArgumentException ignored) { }
            try {
                Location g = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (g != null && System.currentTimeMillis() - g.getTime() < 60000) onLocationChanged(g);
            } catch (SecurityException | IllegalArgumentException ignored) { }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onLocationChanged(Location l) {
        if (l == null) return;
        /* a rough network position right after a good GPS one is skipped */
        if (last != null && LocationManager.NETWORK_PROVIDER.equals(l.getProvider()) && LocationManager.GPS_PROVIDER.equals(last.getProvider())
            && l.getTime() - last.getTime() < 20000) return;
        last = l;
        MainActivity a = MainActivity.live;
        if (a != null) a.locPos(l);
        post(l, false);
    }

    /* ---------- 1.1.39: send the position to the server ourselves ---------- */
    private void post(Location l, boolean force) {
        if (postUrl == null || ticket == null || busy || l == null) return;
        long now = System.currentTimeMillis();
        if (until > 0 && now > until) { endNow(); return; }
        float moved = sent == null ? 1e9f : sent.distanceTo(l);
        if (!force && moved < 8 && now - sentAt < 20000) return;
        if (now - sentAt < 4000) return;
        busy = true; sent = l; sentAt = now;
        final String url = postUrl, body;
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            o.put("a", "live"); o.put("t", ticket); o.put("lat", l.getLatitude()); o.put("lng", l.getLongitude()); o.put("acc", l.hasAccuracy() ? l.getAccuracy() : 50);
            body = o.toString();
        } catch (Exception e) { busy = false; return; }
        net.execute(() -> {
            String r = send(url, body);
            h.post(() -> {
                busy = false;
                MainActivity a = MainActivity.live;
                if (r != null && r.contains("\"ended\":true")) {
                    if (a != null) a.liveNative("ended");
                    /* the app is open (maybe showing the map): it stops us; closed / locked: stop now */
                    if (MainActivity.foreground) { postUrl = null; ticket = null; } else endNow();
                }
                else if (a != null) a.liveNative(r != null && r.contains("\"ok\":true") ? "ok" : "fail");
            });
        });
    }

    private static String send(String url, String body) {
        java.net.HttpURLConnection c = null;
        try {
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(20000);
            c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
            byte[] b = body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(b.length);
            try (java.io.OutputStream o = c.getOutputStream()) { o.write(b); }
            int code = c.getResponseCode();
            java.io.InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
            if (in == null) return null;
            byte[] buf = new byte[2048];
            int n, tot = 0;
            StringBuilder sb = new StringBuilder();
            while ((n = in.read(buf)) > 0 && tot < 8192) { sb.append(new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8)); tot += n; }
            in.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void endNow() { postUrl = null; ticket = null; h.removeCallbacksAndMessages(null); stopSelf(); }

    @Override public void onStatusChanged(String p, int s, Bundle b) { }
    @Override public void onProviderEnabled(String p) { }
    @Override public void onProviderDisabled(String p) { }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        net.shutdown();
        try { if (lm != null) lm.removeUpdates(this); } catch (Exception ignored) { }
        try { if (cpu != null && cpu.isHeld()) cpu.release(); } catch (Exception ignored) { }
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
