package app.tripexpense.calls;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Live location: keeps getting the phone's position while the screen is locked or the app is in the background,
 * and hands every position to the launcher (which sends it to the server like before).
 * Android shows a small "Sharing your live location" notification while it runs.
 */
public class LocationService extends Service implements LocationListener {
    private static final String CH_LOC = "live_loc";
    private static final int ID = 7301;
    private LocationManager lm;
    private PowerManager.WakeLock cpu;
    private Location last;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH_LOC, getString(R.string.ch_loc), NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CH_LOC)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(getString(R.string.loc_t))
            .setContentText(getString(R.string.loc_d))
            .setOngoing(true)
            .setContentIntent(pi)
            .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(ID, n);
        } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }

        if (cpu == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            if (pm != null) { cpu = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "trip:loc"); cpu.setReferenceCounted(false); }
        }
        /* keep the app's page awake enough to send the positions; at most 12 h (sharing lasts at most 8 h) */
        try { if (cpu != null && !cpu.isHeld()) cpu.acquire(12 * 60 * 60 * 1000L); } catch (Exception ignored) { }

        if (lm == null) {
            lm = getSystemService(LocationManager.class);
            try {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 4000, 3, this, Looper.getMainLooper());
            } catch (SecurityException | IllegalArgumentException ignored) { }
            try {
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000, 5, this, Looper.getMainLooper());
            } catch (SecurityException | IllegalArgumentException ignored) { }
            try {
                Location g = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (g != null && System.currentTimeMillis() - g.getTime() < 60000) onLocationChanged(g);
            } catch (SecurityException | IllegalArgumentException ignored) { }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onLocationChanged(Location l) {
        if (l == null) return;
        /* a rough network position right after a good GPS one is skipped */
        if (last != null && LocationManager.NETWORK_PROVIDER.equals(l.getProvider()) && LocationManager.GPS_PROVIDER.equals(last.getProvider())
            && l.getTime() - last.getTime() < 20000) return;
        last = l;
        MainActivity a = MainActivity.live;
        if (a != null) a.locPos(l);
    }

    @Override public void onStatusChanged(String p, int s, Bundle b) { }
    @Override public void onProviderEnabled(String p) { }
    @Override public void onProviderDisabled(String p) { }

    @Override
    public void onDestroy() {
        try { if (lm != null) lm.removeUpdates(this); } catch (Exception ignored) { }
        try { if (cpu != null && cpu.isHeld()) cpu.release(); } catch (Exception ignored) { }
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
